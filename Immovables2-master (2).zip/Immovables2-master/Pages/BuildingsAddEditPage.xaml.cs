﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Immovables.Pages
{
    /// <summary>
    /// Interaction logic for BuildingsAddEditPage.xaml
    /// </summary>
    public partial class BuildingsAddEditPage : Page
    {
        private Buildings _currentperson = new Buildings(); //экземпляр добавляемого пользователя
        public BuildingsAddEditPage(Buildings selectedUser)
        {
            InitializeComponent();
            if (selectedUser != null)
                _currentperson = selectedUser;
            DataContext = _currentperson;
            CmbFiltrOwner.ItemsSource = RealtorEntities.GetContext().Owners.ToList();
            CmbFiltrOwner.SelectedValuePath = "IDOwner";
            CmbFiltrOwner.DisplayMemberPath = "SurName";
        }
        private void Savebtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();// Объект для сообщение об ошибке
            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentperson.Adress))
                error.AppendLine("Укажите Адрес");
            if (string.IsNullOrWhiteSpace(PriceTxt.Text))
                error.AppendLine("Укажите Цену");
            if (string.IsNullOrWhiteSpace(Areatxt.Text))
                error.AppendLine("Укажите Площадь(м3)");
            if (string.IsNullOrWhiteSpace(CmbFiltrOwner.Text))
                error.AppendLine("Укажите Собственника");
            if (string.IsNullOrWhiteSpace(renttxt.Text))
                error.AppendLine("Укажите Цену аренды");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentperson.IDBuilding == 0)
                RealtorEntities.GetContext().Buildings.Add(_currentperson);//Добавить в контекст
            try
            {

                RealtorEntities.GetContext().SaveChanges();// Сохранить изменения
                MessageBox.Show("Данные сохраненны");
                this.NavigationService.Navigate(new BuildingsPage());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void CmbFiltrOwner_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
